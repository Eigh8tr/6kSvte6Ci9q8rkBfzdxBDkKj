@echo off
REM Edit paths before using. Run as a normal interactive user.
cd /d C:\AIGateway
"C:\Python311\python.exe" gateway.py agent --keys keys.json --root C:\Projects\AIWorkspace --audit audit.jsonl
pause
