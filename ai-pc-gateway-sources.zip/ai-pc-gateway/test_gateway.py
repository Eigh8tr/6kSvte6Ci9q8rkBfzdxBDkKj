import json, tempfile, unittest, subprocess, sys, socket, time
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from gateway import Executor, key_valid

class Tests(unittest.TestCase):
    def test_workspace_and_approval(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            ex = Executor(root, approve=lambda action: False)
            with self.assertRaises(ValueError): ex.execute('remote_pc_read', {'path':'../outside'})
            with self.assertRaises(ValueError): ex.execute('remote_pc_write', {'path':'a.txt','text':'blocked'})
            self.assertFalse((root/'a.txt').exists())
            with self.assertRaises(ValueError): ex.execute('remote_pc_run', {'argv':['echo','blocked']})
            ex.approve = lambda action: True
            ex.execute('remote_pc_write', {'path':'a.txt','text':'hello'})
            self.assertEqual(ex.execute('remote_pc_read', {'path':'a.txt'})['text'], 'hello')
            (root/'escape').symlink_to(root.parent, target_is_directory=True)
            with self.assertRaises(ValueError): ex.execute('remote_pc_list', {'path':'escape'})

    def test_integration_and_revocation(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            keys, token = root/'keys.json', root/'token.txt'
            script = str(Path(__file__).with_name('gateway.py'))
            subprocess.run([sys.executable,script,'key-create','--keys',str(keys),'--name','test','--token-file',str(token)],check=True,capture_output=True)
            secret = token.read_text().strip()
            self.assertTrue(key_valid(keys,secret))
            (root/'hello.txt').write_text('integration')
            with socket.socket() as sock:
                sock.bind(('127.0.0.1',0))
                port = sock.getsockname()[1]
            proc = subprocess.Popen([sys.executable,script,'agent','--keys',str(keys),'--root',str(root),'--audit',str(root/'audit.jsonl'),'--port',str(port)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            try:
                for _ in range(100):
                    try:
                        with socket.create_connection(('127.0.0.1',port),timeout=.1): break
                    except OSError: time.sleep(.02)
                messages = [
                    {'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-11-25'}},
                    {'jsonrpc':'2.0','method':'notifications/initialized'},
                    {'jsonrpc':'2.0','id':2,'method':'tools/list'},
                    {'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'remote_pc_read','arguments':{'path':'hello.txt'}}}
                ]
                response = subprocess.run([sys.executable,script,'mcp','--token-file',str(token),'--port',str(port)],input=''.join(json.dumps(m)+'\n' for m in messages),text=True,capture_output=True,check=True)
                replies = [json.loads(line) for line in response.stdout.splitlines()]
                self.assertEqual(len(replies),3)
                self.assertEqual(len(replies[1]['result']['tools']),4)
                self.assertIn('integration',replies[2]['result']['content'][0]['text'])
                subprocess.run([sys.executable,script,'key-revoke','--keys',str(keys),'--name','test'],check=True,capture_output=True)
                request = Request(f'http://127.0.0.1:{port}/tool',data=b'{}',headers={'Authorization':'Bearer '+secret})
                with self.assertRaises(HTTPError) as error: urlopen(request)
                self.assertEqual(error.exception.code,401)
            finally:
                proc.terminate()
                proc.communicate(timeout=5)

if __name__ == '__main__': unittest.main()
