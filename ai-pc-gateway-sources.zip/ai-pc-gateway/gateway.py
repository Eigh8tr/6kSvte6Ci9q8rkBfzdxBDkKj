"""Explicit remote-PC tools, transported over an SSH reverse tunnel."""
import argparse, hashlib, hmac, json, os, secrets, subprocess, sys, threading, time
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, build_opener, ProxyHandler, HTTPRedirectHandler

LIMIT = 256 * 1024
TOOLS = [
    {'name':'remote_pc_list','description':'List files on the REMOTE PC inside its approved workspace.', 'inputSchema':{'type':'object','properties':{'path':{'type':'string'}},'additionalProperties':False}},
    {'name':'remote_pc_read','description':'Read UTF-8 text from the REMOTE PC approved workspace.', 'inputSchema':{'type':'object','properties':{'path':{'type':'string'}},'required':['path'],'additionalProperties':False}},
    {'name':'remote_pc_write','description':'Write UTF-8 text on the REMOTE PC after human approval there.', 'inputSchema':{'type':'object','properties':{'path':{'type':'string'},'text':{'type':'string'}},'required':['path','text'],'additionalProperties':False}},
    {'name':'remote_pc_run','description':'Run an argv command on the REMOTE PC after human approval. Disabled unless explicitly enabled; workspace is NOT an OS sandbox.', 'inputSchema':{'type':'object','properties':{'argv':{'type':'array','items':{'type':'string'},'minItems':1},'cwd':{'type':'string'}},'required':['argv'],'additionalProperties':False}}
]

def digest(token):
    return hashlib.sha256(token.encode()).hexdigest()

def read_keys(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def key_valid(path, token):
    return any(hmac.compare_digest(digest(token), value) for value in read_keys(path).values())

def resolve_path(root, value):
    if not isinstance(value, str):
        raise ValueError('path must be a string')
    candidate = (root / value).resolve()
    if not candidate.is_relative_to(root):
        raise ValueError('Path escapes approved workspace')
    return candidate

class Executor:
    def __init__(self, root, allow_run=False, approve=None):
        self.root = Path(root).resolve(strict=True)
        if not self.root.is_dir():
            raise ValueError('Workspace must be a directory')
        self.allow_run = allow_run
        self.lock = threading.Lock()
        self.approve = approve or self.prompt

    def prompt(self, action):
        print('\nREMOTE ACTION REQUEST:\n' + json.dumps(action, ensure_ascii=True, indent=2), flush=True)
        return input('Type APPROVE to execute: ').strip() == 'APPROVE'

    def execute(self, name, args):
        schema = next((t['inputSchema'] for t in TOOLS if t['name'] == name), None)
        if schema is None or not isinstance(args, dict):
            raise ValueError('Unknown tool or invalid arguments')
        if set(args) - set(schema['properties']) or set(schema.get('required', [])) - set(args):
            raise ValueError('Invalid arguments')
        with self.lock:
            if name == 'remote_pc_run':
                if not self.allow_run:
                    raise ValueError('Command execution disabled. Restart with --allow-run to enable.')
                argv = args['argv']
                if not isinstance(argv, list) or not argv or not all(isinstance(v, str) and v and '\x00' not in v for v in argv):
                    raise ValueError('argv must contain nonempty strings')
                cwd = resolve_path(self.root, args.get('cwd', '.'))
                action = {'tool':name, 'argv':argv, 'cwd':str(cwd)}
                if not self.approve(action):
                    raise ValueError('Denied by local user')
                # Output to disk avoids unbounded memory use. Children are not an OS sandbox.
                import tempfile
                with tempfile.TemporaryFile() as output:
                    proc = subprocess.Popen(argv, cwd=cwd, shell=False, stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT)
                    try:
                        code = proc.wait(timeout=60)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                        proc.wait()
                        raise ValueError('Command timed out; descendants may still be running')
                    output.seek(0)
                    data = output.read(LIMIT + 1)
                return {'exitCode':code, 'output':data[:LIMIT].decode('utf-8', errors='replace'), 'truncated':len(data)>LIMIT}
            target = resolve_path(self.root, args.get('path', '.'))
            if name == 'remote_pc_list':
                import itertools
                entries = list(itertools.islice(target.iterdir(), 501))
                return {'entries':[{'name':p.name, 'directory':p.is_dir()} for p in entries[:500]], 'truncated':len(entries)>500}
            if name == 'remote_pc_read':
                with target.open('rb') as stream:
                    data = stream.read(LIMIT + 1)
                if len(data)>LIMIT:
                    raise ValueError('File exceeds 256 KiB')
                return {'text':data.decode('utf-8')}
            text = args['text']
            if not isinstance(text, str) or len(text.encode('utf-8'))>LIMIT:
                raise ValueError('text must be UTF-8 text under 256 KiB')
            if not self.approve({'tool':name, 'path':str(target), 'text':text}):
                raise ValueError('Denied by local user')
            # Recheck symlinks after approval; workspace must not be concurrently modified by untrusted software.
            target = resolve_path(self.root, args['path'])
            target.write_text(text, encoding='utf-8')
            return {'written':True}

def serve(args):
    executor = Executor(args.root, args.allow_run)
    slots = threading.BoundedSemaphore(1)
    audit_lock = threading.Lock()
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *unused):
            pass  # Never log headers, keys, file contents, or command arguments.
        def reply(self, status, value):
            body = json.dumps(value, ensure_ascii=True).encode()
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Connection', 'close')
            self.end_headers()
            self.wfile.write(body)
        def do_POST(self):
            self.connection.settimeout(15)
            if self.path != '/tool' or self.headers.get('Origin'):
                self.reply(403, {'error':'Forbidden'})
                return
            token = self.headers.get('Authorization', '').removeprefix('Bearer ')
            try:
                authorized = bool(token) and key_valid(args.keys, token)
            except Exception:
                authorized = False
            if not authorized:
                self.reply(401, {'error':'Unauthorized'})
                return
            if not slots.acquire(blocking=False):
                self.reply(429, {'error':'Agent busy'})
                return
            name, status = 'invalid', 'error'
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if size < 1 or size > LIMIT * 6 + 4096:
                    raise ValueError('Invalid request size')
                request = json.loads(self.rfile.read(size))
                name = request['name']
                result = executor.execute(name, request.get('arguments', {}))
                status = 'ok'
                self.reply(200, {'result':result})
            except Exception as exc:
                self.reply(400, {'error':str(exc)})
            finally:
                with audit_lock:
                    with open(args.audit, 'a', encoding='utf-8') as log:
                        log.write(json.dumps({'time':time.time(), 'tool':name if name in [t['name'] for t in TOOLS] else 'invalid', 'status':status})+'\n')
                slots.release()
    server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    server.daemon_threads = True
    print(f'PC agent: 127.0.0.1:{args.port}; workspace: {executor.root}; commands: {args.allow_run}', flush=True)
    server.serve_forever()

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None

def mcp(args):
    token = Path(args.token_file).read_text(encoding='utf-8').strip()
    opener = build_opener(ProxyHandler({}), NoRedirect())
    for line in sys.stdin:
        message = None
        try:
            message = json.loads(line)
            if 'id' not in message:
                continue
            method, params = message.get('method'), message.get('params', {})
            if method == 'initialize':
                offered = params.get('protocolVersion')
                version = offered if offered in ('2024-11-05','2025-03-26','2025-06-18','2025-11-25') else '2025-11-25'
                result = {'protocolVersion':version, 'capabilities':{'tools':{}}, 'serverInfo':{'name':'explicit-remote-pc','version':'0.1.0'}}
            elif method == 'ping':
                result = {}
            elif method == 'tools/list':
                result = {'tools':TOOLS}
            elif method == 'tools/call':
                try:
                    body = json.dumps({'name':params['name'], 'arguments':params.get('arguments', {})}).encode()
                    request = Request(f'http://127.0.0.1:{args.port}/tool', data=body, headers={'Authorization':'Bearer '+token, 'Content-Type':'application/json'})
                    with opener.open(request, timeout=180) as response:
                        value = json.load(response)
                    result = {'content':[{'type':'text','text':json.dumps(value, ensure_ascii=True)}]}
                except Exception as exc:
                    result = {'isError':True,'content':[{'type':'text','text':'Remote tool failed: '+str(exc)}]}
            else:
                print(json.dumps({'jsonrpc':'2.0','id':message['id'],'error':{'code':-32601,'message':'Method not found'}}), flush=True)
                continue
            print(json.dumps({'jsonrpc':'2.0','id':message['id'],'result':result}), flush=True)
        except Exception:
            print(json.dumps({'jsonrpc':'2.0','id':message.get('id') if isinstance(message,dict) else None,'error':{'code':-32603,'message':'Invalid request or internal error'}}), flush=True)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='mode', required=True)
    key = sub.add_parser('key-create')
    key.add_argument('--keys', required=True)
    key.add_argument('--name', required=True)
    key.add_argument('--token-file', required=True)
    revoke = sub.add_parser('key-revoke')
    revoke.add_argument('--keys', required=True)
    revoke.add_argument('--name', required=True)
    agent = sub.add_parser('agent')
    agent.add_argument('--keys', required=True)
    agent.add_argument('--root', required=True)
    agent.add_argument('--audit', default='audit.jsonl')
    agent.add_argument('--port', type=int, default=8765)
    agent.add_argument('--allow-run', action='store_true')
    bridge = sub.add_parser('mcp')
    bridge.add_argument('--token-file', required=True)
    bridge.add_argument('--port', type=int, default=18765)
    args = parser.parse_args()
    if args.mode in ('key-create','key-revoke'):
        path = Path(args.keys)
        keys = read_keys(path) if path.exists() else {}
        if args.mode == 'key-create':
            if args.name in keys:
                raise SystemExit('Name already exists; revoke first')
            token = secrets.token_urlsafe(32)
            with open(args.token_file, 'x', encoding='utf-8') as output:
                output.write(token+'\n')
            os.chmod(args.token_file, 0o600)
            keys[args.name] = digest(token)
        else:
            keys.pop(args.name, None)
        path.write_text(json.dumps(keys, indent=2), encoding='utf-8')
        os.chmod(path, 0o600)
        print('Key configuration updated. Protect token files with OS permissions.')
    elif args.mode == 'agent':
        serve(args)
    else:
        mcp(args)

if __name__ == '__main__':
    main()
