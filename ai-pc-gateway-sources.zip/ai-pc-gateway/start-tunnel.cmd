@echo off
REM Edit user/host. Requires a working SSH key or ssh-agent; no password stored.
:connect
ssh -N -T -o BatchMode=yes -o ExitOnForwardFailure=yes -o ServerAliveInterval=30 -o ServerAliveCountMax=3 -R 127.0.0.1:18765:127.0.0.1:8765 WINDOWS_USER@VPS_HOST
timeout /t 10 /nobreak >nul
goto connect
